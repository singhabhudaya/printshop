
export default function Disputes() {
  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-semibold mb-6">Admin — Disputes</h1>
      <div className="border rounded-xl p-6 text-gray-600">Dispute center will be implemented in Phase 2.</div>
    </div>
  );
}
