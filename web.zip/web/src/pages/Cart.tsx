
export default function Cart() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-semibold mb-4">Cart</h1>
      <div className="text-gray-600">Cart functionality will be added in Phase 2.</div>
    </div>
  );
}
